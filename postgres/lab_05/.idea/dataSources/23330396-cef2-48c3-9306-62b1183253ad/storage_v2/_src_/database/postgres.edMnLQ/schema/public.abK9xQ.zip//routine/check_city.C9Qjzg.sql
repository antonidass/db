create function check_city(check_id jsonb) returns character varying
    language sql
as
$$
SELECT CASE
                WHEN count.cnt > 0
                THEN 'true'
                ELSE 'false'
                END AS comment
    FROM (
            SELECT COUNT(doc->'id') cnt
            FROM city
            WHERE doc -> 'id' @> check_id
    ) as count;
$$;

alter function check_city(jsonb) owner to postgres;

