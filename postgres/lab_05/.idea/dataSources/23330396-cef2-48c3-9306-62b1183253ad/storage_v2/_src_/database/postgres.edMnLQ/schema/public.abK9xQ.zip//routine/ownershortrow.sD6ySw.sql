create function ownershortrow()
    returns TABLE(ow_name character varying, age integer, turnover integer)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT owner_name, age, turnover
    FROM companyowner JOIN balance ON balance.id = CompanyOwner.id;
END;
$$;

alter function ownershortrow() owner to postgres;

