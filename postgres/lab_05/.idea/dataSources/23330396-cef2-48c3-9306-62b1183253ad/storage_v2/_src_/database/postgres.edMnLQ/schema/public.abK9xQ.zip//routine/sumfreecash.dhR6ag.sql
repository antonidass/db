create function sumfreecash(sector_name character varying) returns integer
    language sql
as
$$
SELECT SUM(free_cash)
    FROM Company, Balance
    WHERE sector = sector_name AND Company.balance_id = Balance.id;
$$;

alter function sumfreecash(varchar) owner to postgres;

