create function ownershortrow(id_in integer)
    returns TABLE(ow_name character varying, age integer, turnover integer)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT owner_name, companyowner.age, Balance.turnover
    FROM companyowner JOIN balance ON balance.id = CompanyOwner.balance_id
    WHERE id_in = companyowner.id;
END;
$$;

alter function ownershortrow(integer) owner to postgres;

