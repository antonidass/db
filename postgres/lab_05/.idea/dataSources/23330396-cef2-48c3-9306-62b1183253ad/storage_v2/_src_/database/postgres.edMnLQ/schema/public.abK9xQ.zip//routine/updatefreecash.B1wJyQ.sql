create procedure updatefreecash(IN id_in integer, IN increase_cash integer)
    language plpgsql
as
$$
BEGIN
UPDATE Balance
SET free_cash = free_cash + increase_cash
WHERE id = id_in;
END;
$$;

alter procedure updatefreecash(integer, integer) owner to postgres;

